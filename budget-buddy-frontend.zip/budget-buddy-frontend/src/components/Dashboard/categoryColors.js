export const CATEGORY_PALETTE = [
    '#7c3aed', // violet
    '#22c55e', // green
    '#f59e0b', // amber
    '#ef4444', // red
    '#06b6d4', // cyan
    '#a855f7', // purple
    '#84cc16', // lime
    '#eab308', // yellow
    '#f43f5e', // rose
    '#0ea5e9', // sky
  ];
  